﻿angular.module("umbraco").controller("Import.DeleteAthleteController", function ($scope, $routeParams, $timeout, importResource, editorState) {
    $scope.loaded = true;
    $scope.athlete = {};
    $scope.bazinga = "";

    importResource.getById(0).then(function (response) {
        $scope.athlete = response.data;
    });


    $scope.delete = function () {
        console.log($scope.bazinga);
        importResource.deleteById(0);
    }
});