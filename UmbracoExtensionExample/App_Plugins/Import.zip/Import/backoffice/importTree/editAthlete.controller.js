﻿angular.module("umbraco").controller("Import.ImportEditAthleteController", function ($scope, $routeParams, $timeout, importResource, notificationsService) {

    $scope.loaded = true;

    importResource.getById($routeParams.id).then(function (response) {
        $scope.athlete = response.data;
    });
    

    $scope.edit = function () {

        importResource.edit($routeParams.id, $scope.athlete).then(function (response) {
            if (parseInt(response.data) < 0) //error
                notificationsService.error("Edit Failed", "booooh");
            else
                notificationsService.success("Edit Successfull", "hooraaaay for you!");
        });
    };
});



