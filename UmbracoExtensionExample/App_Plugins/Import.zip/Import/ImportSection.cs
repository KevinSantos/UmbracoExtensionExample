﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using umbraco.businesslogic;
using umbraco.interfaces;

namespace UmbracoExtensionExample.App_Plugins.Import {
    [Application("import", "Import", "icon-smiley", 15)]
    public class ImportSection : IApplication{
    }
}